<?php if ( 'wpps_section-basic' == $section['id'] ) : ?>

	<p>Example section introduction.</p>

<?php elseif ( 'wpps_section-advanced' == $section['id'] ) : ?>

	<p>Another example section introduction.</p>

<?php endif; ?>
