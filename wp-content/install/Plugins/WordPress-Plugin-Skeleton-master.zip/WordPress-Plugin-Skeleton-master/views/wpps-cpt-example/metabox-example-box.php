<p>Meta box introduction / user instructions</p>

<table id="wpps_example-box" class="form-table">
	<tbody>
		<tr>
			<th>
				<label for="wpps_example-box-field">Example Box Field:</label>
			</th>
			<td>
				<input id="wpps_example-box-field" name="wpps_example-box-field" type="text" class="regular-text" value="<?php esc_attr_e( $exampleBoxField ); ?>" />
			</td>
		</tr>
	</tbody>
</table>
